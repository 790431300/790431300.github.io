<xmp><?php
header("location:zhuomian");
exit();
//echo file_get_contents("http://www.nrta.gov.cn/art/2018/10/20/art_2156_39221.html");
?>