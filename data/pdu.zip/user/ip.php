<?php
require('../global.php');
require('system/config.php');
require('system/my_connection.php');
require('system/my_operate.php');
?><!DOCTYPE html><html lang="zh-cn"><head>
<title>用户历史登录IP记录</title>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-touch-fullscreen" content="yes"><meta name="format-detection" content="telephone=no"><meta name="apple-mobile-web-app-status-bar-style" content="black">
</head><body>

<link type="text/css" rel="stylesheet" href="skin/css/basic.css" />
  <header>
    <div class="header"> <a class="new-a-back" href="javascript:history.back();"> <span>返回</span> </a>
      <h2>IP查询</h2>
      <a class="new-a-jd" id="trigger-overlay" href="javascript:void(0)"> <span>导航菜单</span> </a>
      </div>
  </header>

<center style="margin:8px;background:#fff;text-align:center;">

<div class="description_title"><span></span></div>
<br/>

<div id="article" style="background:#eee;border-radius:8px;margin:8px;padding:8px;"><center>
<h3>历史登录IP记录</h3></center><br/>
<div id="lsjl"><?php


function ipurl($ip){

$str = file_get_contents("http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=js&ip={$ip}&qq-pf-to=pcqq.c2c");
$s = explode('var remote_ip_info = ', $str);
$s = explode(';', $s[1]);
$c=json_decode($s[0], true);


return "{$c['country']}/{$c['province']}/{$c['city']}";

}



$res=mysqli_query($my->my_databaselink,"select * from `ip` where name='{$_GET['name']}' order by id desc limit 0,100");
while($row=mysqli_fetch_assoc($res)){

echo '用户名:',$row['name'],'/IP:',$row['ip'],'<br/>';
echo ipurl($row[ip]);
echo '<br/><br/>';
}
mysqli_free_result($res);
?></div>
</div>


</center>

<br/><br/>


<br/><br/>
</body>
</html>