﻿<?php
require('../global.php');
require('system/config.php');
require('system/my_connection.php');
require('system/my_operate.php');

function check_ip($my,$name,$iptxt){


//这里设置IP
$ALLOWED_IP=explode('|',$iptxt);


	$IP=getIP();
	$check_ip_arr= explode('.',$IP);//要检测的ip拆分成数组
	#限制IP
	if(!in_array($IP,$ALLOWED_IP)) {
		foreach ($ALLOWED_IP as $val){
		  if(strpos($val,'*')!==false){//发现有*号替代符
		  	 $arr=array();//
		  	 $arr=explode('.', $val);
		  	 $bl=true;//用于记录循环检测中是否有匹配成功的
		  	 for($i=0;$i<4;$i++){
		  	 	if($arr[$i]!='*'){//不等于* 就要进来检测，如果为*符号替代符就不检查
		  	 		if($arr[$i]!=$check_ip_arr[$i]){
		  	 			$bl=false;
		  	 			break;//终止检查本个ip 继续检查下一个ip
		  	 		}
		  	 	}
		  	 }//end for 
		  	 if($bl){//如果是true则找到有一个匹配成功的就返回
		  	 	return;
		  	 	die;
		  	 }
		  }
		}//end foreach
	 echo("您的登录IP和上一次不一样，账号已被锁定，联系管理员解除---<a href='ip.php?name={$name}'>查看</a>");

xxx($my,$name);

		exit();
	}
}

function xxx($my,$name){
$my->g("user","suo='yes'","name='{$name}'");
}

?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
<title>登录提醒</title>
<link href="../style/hui.css" rel="stylesheet" type="text/css" />
</head>
<body class="H-theme-background-color-eee H-height-100-percent">

<header class="H-header H-theme-background-color1" id="header"><span tapmode="" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100" onclick="window.history.go(-1);"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i>返回</span>
<div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">
登录提醒
</div></header>

<div style="padding:0 8px 8px 8px;background:#eee;margin:0px">

<center style="margin:8px;background:#fff;text-align:center;">

<div class="description_title"><span></span></div>
<br/>

<script src='../script/H.js' type='text/javascript'>
</script>
<script type='text/javascript'>
H.ready(function () {
});
</script>
<?php

//print_r($_POST);

if($_POST['name']==""){
exit("账号或者密码不能为空<br/>
<br/>
<script>
H.alert('账号或者密码不能为空');
</script>
");
}

$c=$my->c("*","user","(name='{$_POST['name']}') and (pass='{$_POST['mm']}') and (suo='no') order by id desc");


$name=$my->c("*","user","(name='{$_POST['name']}') order by id desc");

if(!$c){
exit("账号或密码错误,请您核对后重新输入<br/><br/><a href='zc.html'>注册会员</a>
<br/><br/><script>
H.alert('账号或者密码错误，请您核对后再输入');
</script>
");
}

if($name['suo']=="yes"){
exit("账号已被永久锁定 请勿将账号给予他人使用！");
}

/*
if($name['vip']!="yes"){
exit("您的账号未激活 请先联系客服QQ激活会员<br/><br/>
<a href='jhm.php'><span>点击进入在线激活页面</span></a><br/>
");
}

*/




function getIP() { 
  return isset($_SERVER["HTTP_X_FORWARDED_FOR"])?$_SERVER["HTTP_X_FORWARDED_FOR"] 
  :(isset($_SERVER["HTTP_CLIENT_IP"])?$_SERVER["HTTP_CLIENT_IP"] 
  :$_SERVER["REMOTE_ADDR"]); 
}

$ip=getIP();


$cip=$my->c("*","ip","name='{$_POST["name"]}' order by id desc");

//print_r($cip);


//check_ip($my,$_POST['name'],$cip['ip']);



$mydo=$my->z("ip","name,ip","'{$_POST['name']}','{$ip}'");


setcookie('user_name',"{$_POST['name']}",time()+60*60*24*30,'/');

setcookie('user_pass',"{$_POST['mm']}",time()+60*60*24*30,'/');



?>
-----------登录成功--------<br/><br/>
<script>
H.confirmTip(function (ret) {
if(ret.buttonIndex=="1"){location.href="../users";}else{location.href="../"}}, '确认提示：', '您要进入个人中心吗？');
</script>
<a href="../">点击进入</a>

</center>

<br/><br/>


<br/><br/>
</body>
</html>