<?php
require('../global.php');
require('system/config.php');
require('system/my_connection.php');
require('system/my_operate.php');


//print_r($_POST);
//exit();
?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
<title>注册提醒</title>
<link href="../style/hui.css" rel="stylesheet" type="text/css" />
</head>
<body class="H-theme-background-color-eee H-height-100-percent">

<header class="H-header H-theme-background-color1" id="header"><span tapmode="" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100" onclick="window.history.go(-1);"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i>返回</span>
<div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">
注册提醒
</div></header>

<div style="padding:8px 8px 8px 8px;background:#eee;margin:0px">
<center style="margin:8px;background:#fff;text-align:center;">

<div class="description_title"><span></span></div>
<br/>

<script src='../script/H.js' type='text/javascript'>
</script>
<script type='text/javascript'>
H.ready(function () {
});
</script>
<?php

//print_r($_POST);


$c=$my->c("*","user","name='{$_POST['name']}' order by id desc");

if($c){
exit("账号已被注册，换一个吧
<script>
H.alert('账号已存在');
</script>
<br/><br/>
");
}
if(preg_match("/[\x7f-\xff]/", $_POST['name'])){
echo '用户名不能有中文!
<script>
H.alert("用户名不能有中文");
</script>
';
}elseif($_POST['name']==""){
echo("用户名不能为空
<script>
H.alert('用户名不能为空');
</script>
");
}elseif($_POST['mmm']==""){
echo("密码不能为空
<script>
H.alert('密码不能为空');
</script>
");
}elseif($_POST['mmm']!=$_POST['mma']){
echo("密码和确认密码不一样！
<script>
H.alert('两次密码不一样');
</script>
");
}
/*
elseif($_POST['code'] != "b8px"){
exit("验证码错误");
}
*/
else{
$time=time();



function getIP() { 
  return isset($_SERVER["HTTP_X_FORWARDED_FOR"])?$_SERVER["HTTP_X_FORWARDED_FOR"] 
  :(isset($_SERVER["HTTP_CLIENT_IP"])?$_SERVER["HTTP_CLIENT_IP"] 
  :$_SERVER["REMOTE_ADDR"]); 
}
$ip=getIP();


$timereg=date('ymd');

$regipt=$my->t("select * from `regip` where ip='{$ip}' and time='{$timereg}'");

if($regipt>=10){
exit("-----------一天只能注册10个账号喔，明天再来吧！---------");
}

$myreg=$my->z("regip","ip,time","'{$ip}','{$timereg}'");




/*
$jhm=$my->c("*","jhm","(content='{$_POST['jhm']}') and (kg='no')order by id desc");

if(!$jhm){
exit("激活码不存在！");
}

*/




$pname=$_POST['name'];

$mydo=$my->z("user","name,pass,vip,suo,time,money","'{$_POST['name']}','{$_POST['mmm']}','{$ip}','no','{$time}','0.00'");


if($mydo==1){

if($_POST['tjr'] != ""){
$my->z("dingdan","user,title,out_trade_no,type,money,zhuangtai,time,uid","'{$_POST['tjr']}','推荐注册','{$time}','guigscn','{$w_tj}','0','{$time}','{$pname}'");
}


echo '--------注册成功,赶快<a href="login.html">登录体验吧</a>--------';

}else{
echo "--------注册失败,请尝试重新注册--------";
}

}
?>


<br/><br/>
</center>

<br/><br/>


<br/><br/>
</body>
</html>