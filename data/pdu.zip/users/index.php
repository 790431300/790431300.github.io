<?php
require('../global.php');
require('system/config.php');
require('system/my_connection.php');
require('system/my_operate.php');


$name=$my->user_c($_COOKIE['user_name'],$_COOKIE['user_pass']);

if($name['name']==""){
header("location:../user/login.html");
}

//print_r($name);
?>﻿<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" />
    <meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
    <title>用户中心</title>
    <link href="../style/hui.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
a{text-decoration:none;}
a:hover,a:active,a:link{}
a,li,ul{list-style-type:none}
</style>
</head>
<body>

<header class="H-header H-theme-background-color1" id="header"><span tapmode="" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100" onclick="window.history.go(-1);"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i>返回</span><div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent"></div></header>

<div class="H-horizontal-center H-theme-background-color1 H-overflow-hidden" style="min-height:200px;"><div class="H-overflow-hidden H-max-width-100-percent H-padding-horizontal-both-10 H-box-sizing-border-box"><div class="picture H-position-relative  H-margin-horizontal-auto" style="width: 96px; height: 96px;">
<img src="qq790431300.jpg" onerror="this.src='qq790431300.jpg'" class="H-icon H-center-all H-theme-background-color1 H-border-radius-circle H-margin-horizontal-auto" alt="头像" title="" style="width: 90px; height: 90px; border:3px solid rgba(255,255,255,0.3);" onclick=""/></div>

<strong class="H-display-block H-font-weight-normal H-font-weight-500 H-font-size-18 H-theme-font-color-white H-text-align-center H-margin-vertical-both-8">欢迎您！</strong><div class="H-font-size-12 H-theme-font-color-white H-text-show-row-1"><?php
echo $name['name'].'-';
echo $name['vip']!='yes'?'普通用户':'VIP会员';

$viptime=ceil(($name['viptime']-time())/3600);
if($viptime<0 and $name['viptime']!=""){
echo "-过期
<script src='../script/H.js' type='text/javascript'>
</script>
<script type='text/javascript'>
H.ready(function () {
});
H.confirmTip(function (ret) {
if(ret.buttonIndex=='1'){location.href='vip.php';}}, '会员到期提醒：', '您的会员已到期，需要充值吗？');
</script>
";
}
?>
</div></div>
</div>
<a href="tx.php">
<div class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-margin-left-10-after H-vertical-middle H-touch-active">
<span class="H-icon H-display-block H-margin-horizontal-left-10"><i class="H-iconfont H-icon-money21 H-font-size-22 H-vertical-middle H-theme-font-color2"></i></span><div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">余额提现</div><span class="H-badge H-display-block"><label class="H-display-inline-block H-vertical-middle H-theme-background-color4 H-theme-font-color-white H-font-size-12"><?php
echo $name['money'].'元';
?></label></span><span class="H-icon H-padding-horizontal-right-5 H-display-block"><i class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-14 H-vertical-middle"></i></span></div></a>


<a href="zhangdan.php">
<div class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-margin-left-10-after H-vertical-middle H-touch-active">
<span class="H-icon H-display-block H-margin-horizontal-left-10"><i class="H-iconfont H-icon-find-null H-font-size-22 H-vertical-middle H-theme-font-color1"></i></span><div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">我的下级</div><span class="H-icon H-padding-horizontal-right-5 H-display-block"><i class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-14 H-vertical-middle"></i></span></div></a>
<a href="../qrcode/tg.php?id=<?php echo $name['name']; ?>">
<div class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-margin-left-10-after H-vertical-middle H-touch-active"><span class="H-icon H-display-block H-margin-horizontal-left-10"><i class="H-iconfont H-icon-group-user H-font-size-22 H-vertical-middle H-theme-font-color6"></i></span><div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">推广会员码</div><span class="H-icon H-padding-horizontal-right-5 H-display-block"><i class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-14 H-vertical-middle"></i></span></div></a>


<a href="user-zl.php">
<div class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-margin-left-10-after H-vertical-middle H-touch-active"><span class="H-icon H-display-block H-margin-horizontal-left-10"><i class="H-iconfont H-icon-doc H-font-size-22 H-vertical-middle H-theme-font-color6"></i></span><div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">修改密码</div><span class="H-icon H-padding-horizontal-right-5 H-display-block"><i class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-14 H-vertical-middle"></i></span></div></a>


<a href="vip.php">
<div class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-margin-left-10-after H-vertical-middle H-touch-active"><span class="H-icon H-display-block H-margin-horizontal-left-10"><i class="H-iconfont H-icon-kefu2-fill H-font-size-22 H-vertical-middle H-theme-font-color6"></i></span><div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">会员续费</div><span class="H-icon H-padding-horizontal-right-5 H-display-block"><i class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-14 H-vertical-middle"></i></span></div></a>

<a href="exit.php">
<div class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-margin-left-10-after H-vertical-middle H-touch-active"><span class="H-icon H-display-block H-margin-horizontal-left-10"><i class="H-iconfont H-icon-exit H-font-size-22 H-vertical-middle H-theme-font-color6"></i></span><div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">退出登录</div><span class="H-icon H-padding-horizontal-right-5 H-display-block"><i class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-14 H-vertical-middle"></i></span></div></a>



<div class="H-padding-vertical-bottom-20"><br/><br/></div>
  
<footer class="H-footer H-flexbox-horizontal H-theme-background-color-white H-border-vertical-top-after" id="footer" style="position:fixed;bottom:0">
<div class="H-flex-item H-center-all H-text-align-center H-theme-font-color-999 H-touch-active">
<div>
<span class="H-icon H-display-block H-line-height-normal"><i class="H-iconfont H-icon-fangzi H-font-size-26"></i></span><a href="../index.php"><strong class="H-font-size-11 H-display-block H-font-weight-normal H-margin-vertical-bottom-2">网站首页</strong></a></div></div>
<div class="H-flex-item H-center-all H-text-align-center H-theme-font-color-999 H-touch-active H-theme-font-color1"><div>
<span class="H-icon H-display-block H-line-height-normal"><i class="H-iconfont H-icon-user2 H-font-size-26"></i></span>
<a href="../users"><strong class="H-font-size-11 H-display-block H-font-weight-normal H-margin-vertical-bottom-2">用户中心</strong></a></div></div>
</footer>
</body>
</html>