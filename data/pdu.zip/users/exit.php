<?php
setcookie('user_name',"",time()+60*60*24*30,'/');
setcookie('user_pass',"",time()+60*60*24*30,'/');

header("location:../index.php");
?>