<?php
error_reporting(E_ALL^E_NOTICE^E_WARNING);
require('../global.php');
require('system/config.php');
require('system/my_connection.php');
require('system/my_operate.php');


$name=$my->user_c($_COOKIE['user_name'],$_COOKIE['user_pass']);

if($name['name']==""){

header("location:../user/login.html");

}

?>﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
<title>余额提现</title>
<link href="../style/hui.css" rel="stylesheet" type="text/css" />
</head>
<body class="H-theme-background-color-eee H-height-100-percent">

<header class="H-header H-theme-background-color1" id="header"><span tapmode="" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100" onclick="window.history.go(-1);"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i>返回</span>
<div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">
余额提现
</div></header>

<div style="padding:0 8px 8px 8px;background:#eee;">
<form id="" method="post" enctype="multipart/form-data" action="tx-go.php">
<div class="H-padding-vertical-bottom-10"></div>



<div class="H-flexbox-horizontal H-border-vertical-bottom-margin-left-10-after"><input type="number" name="money" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="提现金额(剩余<?php echo $name['money']; ?>)元"  value="" /></div>

<div class="H-padding-vertical-bottom-10"></div>

<p class="H-padding-horizontal-both-10 H-font-size-16">
只支持支付宝提现，填写错误将无法到账!</p>
<div class="H-flexbox-horizontal H-margin-vertical-bottom-5" style="display:none">
<select name="payname" type="text" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="收款方式" readonly="readonly" />
<option name="payname" value ="支付宝">支付宝收款</option>
<option name="payname" value ="微信">微信收款</option>
<span class="H-icon H-vertical-middle H-padding-horizontal-right-10 H-theme-background-color-white"><i class="H-iconfont H-icon-arrow-down H-font-size-16 H-vertical-middle H-theme-font-color-999"></i></span>
</select>
</div>

<div class="H-flexbox-horizontal H-border-vertical-bottom-margin-left-10-after"><input type="text" name="payuser" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="姓名"  value="<?php echo $name['payuser']; ?>"/></div>

<div class="H-flexbox-horizontal H-border-vertical-bottom-margin-left-10-after"><input type="text" name="payphone" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="收款账号" value="<?php echo $name['payphone']; ?>"/></div>

<div class="H-padding-vertical-bottom-10"></div>
<button class="H-button H-width-100-percent  H-font-size-15 H-outline-none H-padding-vertical-both-12 H-padding-horizontal-both-20 H-theme-background-color1 H-theme-font-color-white H-theme-border-color1 H-theme-border-color1-click H-theme-background-color1-click H-theme-font-color9-click H-border-radius-3">确认提现</button>
<div class="H-padding-vertical-bottom-10"></div>

</form>


</div></div>

<div class="H-padding-vertical-bottom-10"><br/><br/></div>

<footer class="H-footer H-flexbox-horizontal H-theme-background-color-white H-border-vertical-top-after" id="footer" style="position:fixed;bottom:0">
<div class="H-flex-item H-center-all H-text-align-center H-theme-font-color-999 H-touch-active">
<div>
<span class="H-icon H-display-block H-line-height-normal"><i class="H-iconfont H-icon-fangzi H-font-size-26"></i></span><a href="../index.php"><strong class="H-font-size-11 H-display-block H-font-weight-normal H-margin-vertical-bottom-2">网站首页</strong></a></div></div>
<div class="H-flex-item H-center-all H-text-align-center H-theme-font-color-999 H-touch-active"><div>
<span class="H-icon H-display-block H-line-height-normal"><i class="H-iconfont H-icon-user2 H-font-size-26"></i></span>
<a href="../users"><strong class="H-font-size-11 H-display-block H-font-weight-normal H-margin-vertical-bottom-2">用户中心</strong></a></div></div>
</footer>
</body>
</html>