<?php
error_reporting(E_ALL^E_NOTICE^E_WARNING);
require('../global.php');
require('system/config.php');
require('system/my_connection.php');
require('system/my_operate.php');


$name=$my->user_c($_COOKIE['user_name'],$_COOKIE['user_pass']);

if($name['name']==""){

header("location:../user/login.html");

}

?>﻿<!doctype html>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" />
    <meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
    <title>余额提现</title>
    <link href="../style/hui.css" rel="stylesheet" type="text/css" />
<style type="text/css">
.btn{position:relative;overflow:hidden;font-size:14px;vertical-align:middle;cursor:pointer;display:inline-block;*display:inline;width:100%;}
.btn input{position: absolute;top: 0; right: 0;margin: 0;border: solid transparent;opacity: 0;filter:alpha(opacity=0);cursor: pointer;width:100%;}
#upimg img{height:80px;}
button{border:0;}
</style>
</head>
<body class="H-theme-background-color-eee H-height-100-percent">

<header class="H-header H-theme-background-color1" id="header">
        <span tapmode="" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100" onclick="window.history.go(-1);"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i>返回</span>
        <div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">
余额提现
        </div>
    </header>

<script src='../script/H.js' type='text/javascript'>
</script>
<script type='text/javascript'>
H.ready(function () {
});
</script>
<div style="padding:20px 8px 8px 8px;font-size:18px;">
<?php

if($_POST['payuser']==""){
echo "姓名不能为空！<script>
H.alert('姓名不能为空！');
</script>
";


}elseif($_POST['payphone']==""){
echo "收款账号不能为空！<script>
H.alert('收款账号不能为空');
</script>
";


}elseif($name['money']<10){
echo '余额不足10元，满10元才可以提现！赶紧赚钱吧<script>
H.alert("余额不足10元，满10元才可以提现！");
</script>
';


}elseif($_POST['money']>$name['money']){
echo '您的余额不足('.$_POST['money'].')元，最多只能提现('.$name['money'].')元<script>
H.alert("您的余额不足('.$_POST['money'].')元，最多只能提现('.$name['money'].')元");
</script>';


}elseif($_POST['money']<10){
echo '最低只能提现10元<script>
H.alert("最低只能提现10元");
</script>
';
}else{


$time=time();
$tixian=$my->z("tixian","uid,money,payname,payuser,payphone,zhuangtai,time","'{$name['name']}','{$_POST['money']}','{$_POST['payname']}','{$_POST['payuser']}','{$_POST['payphone']}','0','{$time}'");

if($tixian){
$my->z("dingdan","user,title,out_trade_no,type,money,zhuangtai,time,uid","'{$name['name']}','提现','{$time}','guigscn','{$_POST['money']}','1','{$time}','tx'");
$txmoney=$name['money']-$_POST['money'];

$my->g("user","money='{$txmoney}'","name='{$name['name']}'");

echo "提现申请已提交，请等待通知<br/>
<script>
H.alert('提现申请已提交，请等待通知');
</script>
";
}else{
echo '提现申请提交失败，请联系客服<script>
H.alert("提现申请失败，请联系客服");
</script>
';
}
}

?>
</div>



<div class="H-padding-vertical-bottom-10"><br/><br/></div>

<footer class="H-footer H-flexbox-horizontal H-theme-background-color-white H-border-vertical-top-after" id="footer" style="position:fixed;bottom:0">
<div class="H-flex-item H-center-all H-text-align-center H-theme-font-color-999 H-touch-active">
<div>
<span class="H-icon H-display-block H-line-height-normal"><i class="H-iconfont H-icon-fangzi H-font-size-26"></i></span><a href="../index.php"><strong class="H-font-size-11 H-display-block H-font-weight-normal H-margin-vertical-bottom-2">网站首页</strong></a></div></div>
<div class="H-flex-item H-center-all H-text-align-center H-theme-font-color-999 H-touch-active"><div>
<span class="H-icon H-display-block H-line-height-normal"><i class="H-iconfont H-icon-user2 H-font-size-26"></i></span>
<a href="../users"><strong class="H-font-size-11 H-display-block H-font-weight-normal H-margin-vertical-bottom-2">用户中心</strong></a></div></div>
</footer>
</body>
</html>