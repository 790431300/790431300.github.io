<?php
require('../global.php');
require('system/config.php');
require('system/my_connection.php');
require('system/my_operate.php');

$name=$my->user_c($_COOKIE['user_name'],$_COOKIE['user_pass']);

if($name['name']==""){
header("location:../user/login.html");
}

?>﻿<!DOCTYPE html><html><head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta http-equiv="Cache-Control" content="no-cache">
<meta name="imagemode" content="force">
<meta http-equiv="pragma" content="no-cache"> 
<meta http-equiv="expires" content="0">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<title>修改资料</title>
<link href="../style/hui.css" rel="stylesheet" type="text/css" />

<style>
</style>
</head><body>

<header class="H-header H-theme-background-color1" id="header">
<a href="javascript:history.back();"><span tapmode="" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i><label class="H-display-block H-vertical-middle H-font-size-15">返回</label></span></a>
<div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">修改资料</div></header>

<p class="H-padding-horizontal-both-10 H-font-size-16">
</p><div style="margin:8px">

<script src='../script/H.js' type='text/javascript'>
</script>
<script type='text/javascript'>
H.ready(function () {
});
</script>
<?php
if($_POST['m']==""){
echo("密码不能为空<script>
H.toastTip(null,'密码不能为空', 3000);
</script>");
}
elseif($_POST['m'] != $_POST['mm']){
echo("两次密码不一样
<script>
H.toastTip(null,'两次密码不一样', 3000);
</script>
");
}else{

$m=$my->g("user","pass='{$_POST['mm']}'","name='{$name['name']}'");

if($m){
echo "修改成功，<a href='index.php?id={$_GET['id']}'>个人中心</a>";
}else{
exit("修改失败！");
}

}
?>

</div></div>
<div class="H-padding-vertical-bottom-10"><br/><br/></div>

<footer class="H-footer H-flexbox-horizontal H-theme-background-color-white H-border-vertical-top-after" id="footer" style="position:fixed;bottom:0">
<div class="H-flex-item H-center-all H-text-align-center H-theme-font-color-999 H-touch-active">
<div>
<span class="H-icon H-display-block H-line-height-normal"><i class="H-iconfont H-icon-fangzi H-font-size-26"></i></span><a href="../index.php"><strong class="H-font-size-11 H-display-block H-font-weight-normal H-margin-vertical-bottom-2">网站首页</strong></a></div></div>
<div class="H-flex-item H-center-all H-text-align-center H-theme-font-color-999 H-touch-active"><div>
<span class="H-icon H-display-block H-line-height-normal"><i class="H-iconfont H-icon-user2 H-font-size-26"></i></span>
<a href="../users"><strong class="H-font-size-11 H-display-block H-font-weight-normal H-margin-vertical-bottom-2">用户中心</strong></a></div></div>
</footer>
</body>
</html>