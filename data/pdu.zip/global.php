<?php
error_reporting(0);
chdir(dirname(__FILE__));