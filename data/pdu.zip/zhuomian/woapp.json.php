<?php
/*
*如果要修改桌面
*这里提供所有应用的json
*尝试一下吧
*/

require('array.php');
echo json_encode($woapp);