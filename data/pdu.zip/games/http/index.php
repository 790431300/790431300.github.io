<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
<title>网站管理</title>
<link href="../../style/hui.css" rel="stylesheet" type="text/css" />
</head>
<body>

<header class="H-header H-theme-background-color1" id="header"><a href="JavaScript:history.back();"><span tapmode="" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i><label class="H-display-block H-vertical-middle H-font-size-15"></label></span></a>
<div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">网站管理</div></header>

<div class="H-margin-vertical-top-10 H-theme-background-color-white H-border-vertical-both-after" style="padding:12px">
一个人开发，时间不够，如果可以，你来开发吧，配置Apache，就行了，打开文件管理，修改Apache的conf文件，就能搭建网站了，不懂可以百度哟
</div>
</body>
</html>