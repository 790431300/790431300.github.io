<?php
$id="12345678";
if(strstr($id,$_GET['id'])){
header("location:book/?id=bagua/{$_GET['id']}");
}
if($_GET['id']=="文言文"){
header("location:../fanyi");
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no"><title>易经解卦</title>
<link href="style/style.css" rel="stylesheet" type="text/css" />
<link href="../../style/hui.css" rel="stylesheet" type="text/css" />
<style>.y{display:none;}.x{display:auto;}td img{width:24px;height:14px;}</style>
</head><body>
<header class="H-header H-theme-background-color3" id="header"><a href="JavaScript:history.back();"><span class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i><label class="H-display-block H-vertical-middle H-font-size-15">返回</label></span></a><div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">易经解卦</div></header>
<div class="wid mtop10 clearfix" id="topclass"><br/>
<form method="GET" action="jiegua.php" id="form">
<input type="text" name="id" placeholder="输入卦号" class="input" id="text" value="">
<input id="sub" value="解卦" type="submit" name="sub" onclick="tishi" class="input">
</form><br/>
</div>
<?php
$data=file_get_contents("data/{$_GET['id']}.txt");

if($data==""){
echo '
<div class="H-border-vertical-both-after H-theme-background-color-white" style="margin:8px 8px 32px 8px;padding:8px; white-space:pre-wrap;word-break: break-all;">

序卦传

﻿    有天地，然后万物生焉。盈天地之间者，唯万物，故受之以屯；屯者盈也，屯者物之始生也。

    物生必蒙，故受之以蒙；蒙者蒙也，物之穉也。物穉不可不养也，故受之以需；需者饮食之道也。

    饮食必有讼，故受之以讼。讼必有众起，故受之以师；师者众也。众必有所比，故受之以比；比者比也。

    比必有所畜也，故受之以小畜。物畜然后有礼，故受之以履。履而泰，然后安，故受之以泰；泰者通也。

    物不可以终通，故受之以否。物不可以终否，故受之以同人。与人同者，物必归焉，故受之以大有。

    有大者不可以盈，故受之以谦。有大而能谦，必豫，故受之以豫。豫必有随，故受之以随。

    以喜随人者，必有事，故受之以蛊；蛊者事也。有事而后可大，故受之以临；临者大也。

    物大然后可观，故受之以观。可观而后有所合，故受之以噬嗑；嗑者合也。

    物不可以苟合而已，故受之以贲；贲者饰也。致饰然后亨，则尽矣，故受之以剥；剥者剥也。

    物不可以终尽，剥穷上反下，故受之以复。复则不妄矣，故受之以无妄。

    有无妄然后可畜，故受之以大畜。物畜然后可养，故受之以颐；颐者养也。

    不养则不可动，故受之以大过。物不可以终过，故受之以坎；坎者陷也。

    陷必有所丽，故受之以离；离者丽也。有天地，然后有万物；有万物，然后有男女；有男女，然后有夫妇；有夫妇，然后有父子；有父子然后有君臣；有君臣，然后有上下；有上下，然后礼仪有所错。

    夫妇之道，不可以不久也，故受之以恒；恒者久也。物不可以久居其所，故受之以遯；遯者退也。

    物不可终遯，故受之以大壮。物不可以终壮，故受之以晋；晋者进也。

    进必有所伤，故受之以明夷；夷者伤也。伤於外者，必反其家，故受之以家人。

    家道穷必乖，故受之以睽；睽者乖也。乖必有难，故受之以蹇；蹇者难也。

    物不可终难，故受之以解；解者缓也。缓必有所失，故受之以损；损而不已，必益，故受之以益。

    益而不已，必决，故受之以夬；夬者决也。决必有所遇，故受之以姤；姤者遇也。

    物相遇而后聚，故受之以萃；萃者聚也。聚而上者，谓之升，故受之以升。

    升而不已，必困，故受之以困。困乎上者，必反下，故受之以井。井道不可不革，故受之以革。

    革物者莫若鼎，故受之以鼎。主器者莫若长子，故受之以震；震者动也。

    物不可以终动，止之，故受之以艮；艮者止也。物不可以终止，故受之以渐；渐者进也。

    进必有所归，故受之以归妹。得其所归者必大，故受之以丰；丰者大也。

    穷大者必失其居，故受之以旅。旅而无所容，故受之以巽；巽者入也。

    入而后说之，故受之以兑；兑者说也。说而后散之，故受之以涣；涣者离也。

    物不可以终离，故受之以节。节而信之，故受之以中孚。有其信者，必行之，故受之以小过。

    有过物者，必济，故受之既济。物不可穷也，故受之以未济终焉。

------------

杂卦传

﻿    乾刚，坤柔，比乐，师忧。

    临、观之义，或与或求。

    屯见而不失其居。蒙杂而著。

    震起也，艮止也；损益盛衰之始也。

    大畜时也。无妄灾也。

    萃聚，而升不来也。谦轻，而豫怠也。

    噬嗑食也，贲无色也。

    兑见，而巽伏也。

    随无故也，蛊则饬也。

    剥烂也，复反也。

    晋昼也，明夷诛也。

    井通，而困相遇也。

    咸速也，恒久也。

    涣离也，节止也；解缓也，蹇难也；睽外也，家人内也；否泰反其类也。

    大壮则止，遯则退也。

    大有众也，同人亲也；革去故也，鼎取新也；小过过也，中孚信也；丰多故，亲寡旅也。

    离上，而坎下也。小畜寡也，履不处也。需不进也，讼不亲也。

    大过颠也。姤遇也，柔遇刚也。渐女归，待男行也。颐养正也，既济定也。归妹女之终也。未济男之穷也。夬决也，刚决柔也，君子道长，小人道忧也。</div>';
}else{
echo $data;
}
?>

<div id="footer">
<div id="foot" class="ac" style="position:relative"><p><a href="index.php">首页</a><span class="sp">|</span>触屏版<span class="sp">|</span><a href="book/?id=jieshi">关于</a></p><p>©2015 因谋学(yinmouxue.com)</p></div></div>

</body></html>