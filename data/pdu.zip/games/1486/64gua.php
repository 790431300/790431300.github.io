<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no"><title>六十四卦</title>
<link href="style/style.css" rel="stylesheet" type="text/css" />
<link href="../../style/hui.css" rel="stylesheet" type="text/css" />
<style>.y{display:none;}.x{display:auto;}.img{margin:24px 8px 20px 8px;}.img img{width:24px;height:14px;}</style>
</head><body>
<header class="H-header H-theme-background-color3" id="header"><a href="JavaScript:history.back();"><span class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i><label class="H-display-block H-vertical-middle H-font-size-15">返回</label></span></a><div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">六十四卦</div></header>
<div class="wid mtop10 clearfix" id="topclass"><br/>
<form method="GET" action="jiegua.php" id="form">
<input type="text" name="id" placeholder="输入卦号" class="input" id="text" value="">
<input id="sub" value="解卦" type="submit" name="sub" onclick="tishi" class="input">
</form>
</div>

<div class="img">从下往上画，<img src="book/data/bagua/picture/6.png">为阴爻为6，<img src="book/data/bagua/picture/9.png">为阳爻为9</div>

<div class="H-border-vertical-both-after" style="margin:8px;">
<?php
function bagua($阳,$阴){
echo '<a href="jiegua.php?id='.$阳.'" class="H-display-table-cell H-float-left H-box-sizing-border-box H-width-avg-8 H-center-all H-theme-background-color-white H-border-horizontal-right-after H-border-vertical-bottom-after H-padding-vertical-both-10 H-touch-active H-position-relative" style="min-height:80px;"><div class="H-text-align-center"><span class="H-icon H-center-all H-theme-background-color H-margin-horizontal-auto H-font-size-26 H-font-weight-600 H-border-radius-12 H-theme-font-color-white"><img src="64gua/'.$阳.'.gif" class="H-display-block" style="height:42px;width:32px;line-height:42px;"></span><label class="H-display-block H-font-size-11 H-margin-vertical-top-5 H-theme-font-color-666">'.$阳.'</label></div></a>
<a href="jiegua.php?id='.$阴.'" class="H-display-table-cell H-float-left H-box-sizing-border-box H-width-avg-8 H-center-all H-theme-background-color-white H-border-horizontal-right-after H-border-vertical-bottom-after H-padding-vertical-both-10  H-touch-active H-position-relative" style="min-height: 80px;"><div class="H-text-align-center"><span class="H-icon H-center-all H-theme-background-color H-margin-horizontal-auto H-font-size-26 H-font-weight-600 H-border-radius-12 H-theme-font-color-white"><img src="64gua/'.$阴.'.gif" class="H-display-block" style="height:42px;width:32px;line-height:42px;"></span><label class="H-display-block H-font-size-11 H-margin-vertical-top-5 H-theme-font-color-666">'.$阴.'</label></div></a>';
}

$八卦=array(999,996,969,966,699,696,669,666);

for($i=0;$i<8;$i++){
$a0=$八卦['0'].$八卦[$i];
$a7=$八卦['1'].$八卦[$i];
echo bagua($a0,$a7);
$a1=$八卦['2'].$八卦[$i];
$a6=$八卦['3'].$八卦[$i];
echo bagua($a1,$a6);
$a2=$八卦['4'].$八卦[$i];
$a5=$八卦['5'].$八卦[$i];
echo bagua($a2,$a5);
$a3=$八卦['6'].$八卦[$i];
$a4=$八卦['7'].$八卦[$i];
echo bagua($a3,$a4);
}
?>
</div>

<div id="footer">
<div id="foot" class="ac" style="position:relative"><p><a href="index.php">首页</a><span class="sp">|</span>触屏版<span class="sp">|</span><a href="book/?id=jieshi">关于</a></p><p>©2015 因谋学(yinmouxue.com)</p></div></div>

</body></html>