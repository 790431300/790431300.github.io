<?php
$data=file_get_contents("data/{$_GET['id']}.txt");
if($data==""){
$data=file_get_contents("data/index.txt");
}
$data=explode("{沃数据}",$data);
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no"><title><?php
echo $data['0'];
?></title>
<link href="../style/style.css" rel="stylesheet" type="text/css" />
<link href="../../../style/hui.css" rel="stylesheet" type="text/css" />
<style>.y{display:none;}.x{display:auto;}</style>
</head><body>
<header class="H-header H-theme-background-color3" id="header"><a href="JavaScript:history.back();"><span class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i><label class="H-display-block H-vertical-middle H-font-size-15">返回</label></span></a><div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent"><?php echo $data['0']; ?></div></header>
<div class="wid mtop10 clearfix" id="topclass"><br/>
<form method="GET" action="../jiegua.php" id="form">
<input type="text" name="id" placeholder="输入卦号" class="input" id="text" value="">
<input id="sub" value="解卦" type="submit" name="sub" onclick="tishi" class="input">
</form><br/>
</div>
<?php
if(strstr($_GET['id'],"wo")){
require('../../../global.php');
require('system/config.php');
require('system/my_connection.php');
require('system/my_operate.php');
$name=$my->user_c($_COOKIE['user_name'],
$_COOKIE['user_pass']);

if($name['vip']!='yes'){
exit("<div style='margin:8px'>会员才能查看本教学，<a href='../../../users/vip.php'>点击开通</a></div>");
}
}

echo $data['1'];
?>


<div id="footer">
<div id="foot" class="ac" style="position:relative"><p><a href="../">首页</a><span class="sp">|</span>触屏版<span class="sp">|</span><a href="?id=jieshi">关于</a></p><p>©2015 因谋学(yinmouxue.com)</p></div></div>
</body></html>