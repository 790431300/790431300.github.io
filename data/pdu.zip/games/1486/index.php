<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no"><title>易经阴阳</title>
<link href="style/style.css" rel="stylesheet" type="text/css" />
<link href="../../style/hui.css" rel="stylesheet" type="text/css" />
<style>.y{display:none;}.x{display:auto;}</style>
</head><body>
<header class="H-header H-theme-background-color3" id="header"><a href="JavaScript:history.back();"><span class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i><label class="H-display-block H-vertical-middle H-font-size-15">返回</label></span></a><div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">成人之学-修仙之基</div><span id="drop-menu" class="H-icon H-position-relative H-display-inline-block H-float-right H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-10 H-z-index-100" style="white-space: pre-wrap"><i class="H-iconfont H-icon-dot-more H-font-size-22 H-vertical-middle"></i>  </span></header>

<div class="show-menu H-display-none-important H-position-absolute H-width-100-percent H-z-index-1000000 H-horizontal-left-0 H-vertical-bottom-0 H-horizontal-right-0 " style="top:35px;">
<div class="more-info-menu H-width-150 H-vertical-top-10  H-position-absolute H-theme-background-color-white H-padding-vertical-both-5 H-border-radius-3 H-z-index-10" style="right: 4px; -webkit-transform-origin: 150px 0;">
<div class="H-bugle-top H-theme-border-color-white H-position-absolute H-z-index-100" style="border-width: 10px; top: -18px; right:9px;"></div>
<div onclick="location.href='../../users'" class="H-text-list H-flexbox-horizontal  H-theme-background-color-white  H-vertical-middle H-touch-active">
<span class="H-icon H-display-block H-margin-horizontal-left-10"><i class="H-iconfont H-icon-user H-font-size-20 H-vertical-middle H-theme-font-color1"></i></span>
<div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-8 H-theme-font-color-444">个人中心</div>
</div>
<div onclick="alert('输入框内输入(文言文)三个字，可打开翻译功能');" class="H-text-list H-flexbox-horizontal  H-theme-background-color-white  H-vertical-middle H-touch-active">
<span class="H-icon H-display-block H-margin-horizontal-left-10"><i class="H-iconfont H-icon-log H-font-size-20 H-vertical-middle H-theme-font-color1"></i></span>
<div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-8 H-theme-font-color-444">隐藏功能</div>
</div>

</div></div>


<div class="wid mtop10 clearfix" id="topclass"><br/>
<form method="GET" action="jiegua.php" id="form">
<input type="text" name="id" placeholder="输入卦号" class="input" id="text" value="">
<input id="sub" value="解卦" type="submit" name="sub" onclick="tishi" class="input">
</form><br/>
</div>
<div class="H-border-vertical-both-after" style="margin:8px;">
<a href="yinyang" class="H-display-table-cell H-float-left H-box-sizing-border-box H-width-avg-4 H-center-all H-theme-background-color-white H-border-horizontal-right-after H-border-vertical-bottom-after H-padding-vertical-both-10  H-touch-active H-position-relative" style="min-height:80px;"><div class="H-text-align-center"><span class="H-icon H-center-all H-theme-background-color H-margin-horizontal-auto H-font-size-26 H-font-weight-600 H-border-radius-12 H-theme-font-color-white"><img src="picture/2.jpg" class="H-display-block" style="height:42px;width:42px;line-height:42px;"></span><label class="H-display-block H-font-size-11 H-margin-vertical-top-5 H-theme-font-color-666">阴阳</label></div></a>

<a href="book/?id=4" class="H-display-table-cell H-float-left H-box-sizing-border-box H-width-avg-4 H-center-all H-theme-background-color-white H-border-horizontal-right-after H-border-vertical-bottom-after H-padding-vertical-both-10  H-touch-active H-position-relative" style="min-height: 80px;"><div class="H-text-align-center"><span class="H-icon H-center-all H-theme-background-color H-margin-horizontal-auto H-font-size-26 H-font-weight-600 H-border-radius-12 H-theme-font-color-white"><img src="picture/4.jpg" class="H-display-block" style="height:42px;width:42px;line-height:42px;"></span><label class="H-display-block H-font-size-11 H-margin-vertical-top-5 H-theme-font-color-666">四象</label></div></a>


<a href="book/?id=bagua/1" class="H-display-table-cell H-float-left H-box-sizing-border-box H-width-avg-4 H-center-all H-theme-background-color-white H-border-horizontal-right-after H-border-vertical-bottom-after H-padding-vertical-both-10  H-touch-active H-position-relative" style="min-height: 80px;"><div class="H-text-align-center"><span class="H-icon H-center-all H-theme-background-color H-margin-horizontal-auto H-font-size-26 H-font-weight-600 H-border-radius-12 H-theme-font-color-white"><img src="picture/8.jpg" class="H-display-block" style="height:42px;width:42px;line-height:42px;"></span><label class="H-display-block H-font-size-11 H-margin-vertical-top-5 H-theme-font-color-666">八卦</label></div></a>


<a href="64gua.php" class="H-display-table-cell H-float-left H-box-sizing-border-box H-width-avg-4 H-center-all H-theme-background-color-white H-border-horizontal-right-after H-border-vertical-bottom-after H-padding-vertical-both-10  H-touch-active H-position-relative" style="min-height: 80px;"><div class="H-text-align-center"><span class="H-icon H-center-all H-theme-background-color H-margin-horizontal-auto H-font-size-26 H-font-weight-600 H-border-radius-12 H-theme-font-color-white"><img src="picture/64.jpg" class="H-display-block" style="height:42px;width:42px;line-height:42px;"></span><label class="H-display-block H-font-size-11 H-margin-vertical-top-5 H-theme-font-color-666">六十四卦</label></div></a>

<a href="../lp" class="H-display-table-cell H-float-left H-box-sizing-border-box H-width-avg-4 H-center-all H-theme-background-color-white H-border-horizontal-right-after H-border-vertical-bottom-after H-padding-vertical-both-10  H-touch-active H-position-relative" style="min-height: 80px;"><div class="H-text-align-center"><span class="H-icon H-center-all H-theme-background-color H-margin-horizontal-auto H-font-size-26 H-font-weight-600 H-border-radius-12 H-theme-font-color-white"><img src="picture/lp.jpg" class="H-display-block" style="height:42px;width:42px;line-height:42px;"></span><label class="H-display-block H-font-size-11 H-margin-vertical-top-5 H-theme-font-color-666">罗盘</label></div></a>

<a href="book/?id=liuyao" class="H-display-table-cell H-float-left H-box-sizing-border-box H-width-avg-4 H-center-all H-theme-background-color-white H-border-horizontal-right-after H-border-vertical-bottom-after H-padding-vertical-both-10  H-touch-active H-position-relative" style="min-height: 80px;"><div class="H-text-align-center"><span class="H-icon H-center-all H-theme-background-color H-margin-horizontal-auto H-font-size-26 H-font-weight-600 H-border-radius-12 H-theme-font-color-white"><img src="picture/6.jpg" class="H-display-block" style="height:42px;width:42px;line-height:42px;"></span><label class="H-display-block H-font-size-11 H-margin-vertical-top-5 H-theme-font-color-666">六爻</label></div></a>

<a href="book" class="H-display-table-cell H-float-left H-box-sizing-border-box H-width-avg-4 H-center-all H-theme-background-color-white H-border-horizontal-right-after H-border-vertical-bottom-after H-padding-vertical-both-10  H-touch-active H-position-relative" style="min-height: 80px;"><div class="H-text-align-center"><span class="H-icon H-center-all H-theme-background-color H-margin-horizontal-auto H-font-size-26 H-font-weight-600 H-border-radius-12 H-theme-font-color-white"><img src="picture/xue.jpeg" class="H-display-block" style="height:42px;width:42px;line-height:42px;"></span><label class="H-display-block H-font-size-11 H-margin-vertical-top-5 H-theme-font-color-666">教程</label></div></a>

<a href="book/?id=jieshi" class="H-display-table-cell H-float-left H-box-sizing-border-box H-width-avg-4 H-center-all H-theme-background-color-white H-border-horizontal-right-after H-border-vertical-bottom-after H-padding-vertical-both-10  H-touch-active H-position-relative" style="min-height:80px;"><div class="H-text-align-center"><span class="H-icon H-center-all H-theme-background-color H-margin-horizontal-auto H-font-size-26 H-font-weight-600 H-border-radius-12 H-theme-font-color-white"><img src="picture/wo.jpg" class="H-display-block" style="height:42px;width:42px;line-height:42px;"></span><label class="H-display-block H-font-size-11 H-margin-vertical-top-5 H-theme-font-color-666">关于</label></div></a>
</div>

<div class="H-border-vertical-both-after H-theme-background-color-white" style="margin:8px;padding:8px;"><br/>
从出生到死亡这段时间叫过程，过程中必有阴阳，阴阳变动过程也随之变动。<br/><br/>
过程=结果=祸-福\吉-凶，得-失\成-败，高-矮\胖-瘦，富贵-贫穷。<br/><br/>
锻炼=动则瘦，静则胖，胖瘦改变美丑，美丑改变得失，得到小哥哥们的情书，失去往常的平静，阴阳变化，过程就会变化。<br/><br/>
充值联系：<br/>
QQ：790431300，WX：guigs_cn<br/><br/>要相信学有所得，我并不是为了坑钱，我对钱不敢兴趣，只是因为肚子好饿，修仙使我五弊三缺。<br/>
<br/>
</div>

<div id="footer">
<div id="foot" class="ac" style="position:relative"><p><a href="">首页</a><span class="sp">|</span>触屏版<span class="sp">|</span><a href="book/?id=jieshi">关于</a></p><p>©2015 因谋学(yinmouxue.com)</p></div></div>


<script src="../../script/h.js" type="text/javascript"></script>
<script type="text/javascript">
H.D("#drop-menu").addEventListener("touchstart",function (e) {
if (H.isAPICloud()) {
showDropMenu();
}else{
H.swiperShare(".show-menu", ".more-info-menu", "show-menu");
}
});
function bc(){
//H.toast('正在保存...');
document.getElementById("formx").submit();
}
</script>

</body></html>