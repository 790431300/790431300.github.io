<?php
require('../../../global.php');
require('system/config.php');
require('admin/decide.php');
require('system/my_connection.php');
require('system/my_operate.php');
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no"><title>易经阴阳</title>
<link href="../style/style.css" rel="stylesheet" type="text/css" />
<link href="../../../style/hui.css" rel="stylesheet" type="text/css" />
<style>.y{display:none;}.x{display:auto;}img{height:14px;}td{text-align:center;}</style>
</head><body>
<header class="H-header H-theme-background-color3" id="header"><a href="JavaScript:history.back();"><span class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i><label class="H-display-block H-vertical-middle H-font-size-15">返回</label></span></a><div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">易经阴阳</div></header>
<div class="wid mtop10 clearfix" id="topclass"><br/>
<form method="GET" action="../jiegua.php" id="form">
<input type="text" name="id" placeholder="输入卦号" class="input" id="text" value="">
<input id="sub" value="解卦" type="submit" name="sub" onclick="tishi" class="input">
</form><br/>
</div>
<div class="H-overflow-scrolling H-margin-8 H-position-relative">
<table class="H-table H-table-fixed H-theme-background-color-white H-border-vertical-top-after H-border-horizontal-left-after">
<thead><tr><th class="H-padding-10 H-vertical-align-middle H-font-size-15 H-font-weight-500 H-theme-background-color-f4f4f4 H-border-vertical-bottom-after H-border-horizontal-right-after">阴<img src="../book/data/bagua/picture/6.png"></th>
<th class="H-padding-10 H-vertical-align-middle H-font-size-15 H-font-weight-500 H-theme-background-color-f4f4f4 H-border-vertical-bottom-after H-border-horizontal-right-after">阳<img src="../book/data/bagua/picture/9.png"></th>

<th class="H-padding-10 H-vertical-align-middle H-font-size-15 H-font-weight-500 H-theme-background-color-f4f4f4 H-border-vertical-bottom-after H-border-horizontal-right-after" style="width:100%">属性—分类—物品</th>
</tr></thead>
<tbody>
<?php
if(!@$_GET['page']){
@$_GET['page']=0;
}
$x=@$_GET['page']*60;
$y=$t/60;
$sql="select * from `yinyang` order by id asc limit {$x},60";

$re=mysqli_query($my->my_databaselink,$sql);
while($res=mysqli_fetch_assoc($re)){
echo "<tr><td class=\"H-padding-10 H-vertical-align-middle H-font-size-14 H-border-vertical-bottom-after H-border-horizontal-right-after\"><span class=\"H-display-inline-block H-padding-horizontal-both-5\">{$res['yin']}</span></td>
<td class=\"H-padding-10 H-vertical-align-middle H-font-size-14 H-border-vertical-bottom-after H-border-horizontal-right-after\">{$res['yang']}</td>
<td class=\"H-padding-10 H-vertical-align-middle H-font-size-14 H-border-vertical-bottom-after H-border-horizontal-right-after\">{$res['shuxing']}</td></tr>";
}
?>
</tbody></table></div>
<?php
$上一页=$_GET['page']-1;
$下一页=$_GET['page']+1;
if($_GET['page']<=-1){
echo "<p style='margin:8px'>上一页什么也没有</p>";
$_GET['page']=0;
}elseif($y<$_GET['page']){
$_GET['page']=intval($y);
echo "<br/><p style='margin:8px'>已经是最后一页了</p>";
}
?></div></div>

<div class="H-theme-background-color-white H-margin-8">
<div class="H-border-vertical-bottom-after H-flexbox-horizontal">
<div class="H-flex-item H-text-show-row-1 H-padding-vertical-both-10 H-box-sizing-border-box H-border-horizontal-right-after H-touch-active"><a href="?page=<?php 
echo $上一页;
?>"><span class="H-font-size-14 H-theme-font-color-999 H-center-all">上一页</span></a></div>
<div class="H-flex-item H-text-show-row-1 H-padding-vertical-both-10 H-box-sizing-border-box H-border-horizontal-right-after H-touch-active"><span class="H-font-size-14 H-theme-font-color-999 H-center-all"><?php echo $_GET['page']+1; ?></span></div>
<div class="H-flex-item H-text-show-row-1 H-padding-vertical-both-10 H-box-sizing-border-box H-border-horizontal-left-after H-touch-active"><a href="?page=<?php 
echo $下一页;
?>"><span class="H-font-size-14 H-theme-font-color-999 H-center-all">下一页</span></a></div>

</div></div>

<div id="footer">
<div id="foot" class="ac" style="position:relative"><p><a href="../">首页</a><span class="sp">|</span>触屏版<span class="sp">|</span><a href="?id=jieshi">关于</a></p><p>©2015 因谋学(yinmouxue.com)</p></div></div>

</body></html>