<?php
if(!$_GET['text']){
echo "请输入内容";
}else{
$url="https://fanyi-api.baidu.com/api/trans/vip/translate/";
$q=$_GET['text'];
$salt="24864";
$sign=md5("20190902000331370{$q}{$salt}UMMkNbr60DQMacYdJATQ");

$text=file_get_contents("{$url}?q={$q}&from=wyw&to=zh&appid=20190902000331370&salt={$salt}&sign={$sign}");
$json=json_decode($text);
echo $json->trans_result[0]->dst;

exit();
}