<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
<title>应用商店</title>
<link href="../../style/hui.css" rel="stylesheet" type="text/css" />
</head>
<body>

<header class="H-header H-theme-background-color1" id="header"><a href="JavaScript:history.back();"><span tapmode="" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i><label class="H-display-block H-vertical-middle H-font-size-15"></label></span></a>
<div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">应用商店</div></header>

<div class="H-margin-vertical-top-10 H-theme-background-color-white H-border-vertical-both-after" style="padding:12px">
应用商店功能开发中，如果想要安装应用，或是了解本应用最新消息，看下方文字。<br/><br/>
关注网站：http://biniwan.com
</div>
</body>
</html>