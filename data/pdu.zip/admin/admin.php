<?php
require('../global.php');
require('system/config.php');
require('admin/decide.php');
require('system/my_connection.php');
require('system/my_operate.php');
if($logindecide==false){
header('location:index.php');
}

if(!$_GET['page']){
$_GET['page']=0;
}
$x=$_GET['page']*20;

$t=$my->t("select * from `user`");
$tvip=$my->t("select * from `user` where vip='yes'");
?>﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
<title>管理中心</title>
<link href="../style/hui.css" rel="stylesheet" type="text/css" />
</head>
<body class="H-theme-background-color-eee H-height-100-percent">

<header class="H-header H-theme-background-color1" id="header"><span tapmode="" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100" onclick="window.history.go(-1);"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i>返回</span>
<div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">
后台管理
</div></header>

<div class="H-padding-vertical-bottom-0"></div><div class="H-n-grid H-border-vertical-top-after H-clear-both  H-overflow-auto"><div class="H-clear-both H-width-100-percent H-display-table H-box-sizing-border-box" id="jz_text">
<a href="class.php" class="H-display-table-cell H-float-left H-box-sizing-border-box H-width-avg-4 H-center-all H-theme-background-color-white H-border-horizontal-right-after H-border-vertical-bottom-after H-padding-vertical-both-10  H-touch-active H-position-relative" style="min-height: 80px;"><div class="H-text-align-center"><span class="H-icon H-center-all H-theme-background-color H-margin-horizontal-auto H-font-size-26 H-font-weight-600 H-border-radius-12 H-theme-font-color-white"><img src="../games/1486/picture/2.jpg" class="H-display-block" style="height:42px;width:42px;line-height:42px;"></span><label class="H-display-block H-font-size-11 H-margin-vertical-top-5 H-theme-font-color-666">栏目管理</label>
</div></a>

<a href="jhm.php" class="H-display-table-cell H-float-left H-box-sizing-border-box H-width-avg-4 H-center-all H-theme-background-color-white H-border-horizontal-right-after H-border-vertical-bottom-after H-padding-vertical-both-10  H-touch-active H-position-relative" style="min-height: 80px;"><div class="H-text-align-center"><span class="H-icon H-center-all H-theme-background-color H-margin-horizontal-auto H-font-size-26 H-font-weight-600 H-border-radius-12 H-theme-font-color-white"><img src="../games/1486/picture/4.jpg" class="H-display-block" style="height:42px;width:42px;line-height:42px;"></span><label class="H-display-block H-font-size-11 H-margin-vertical-top-5 H-theme-font-color-666">激活码管理</label>
</div></a>

<a href="vip.php" class="H-display-table-cell H-float-left H-box-sizing-border-box H-width-avg-4 H-center-all H-theme-background-color-white H-border-horizontal-right-after H-border-vertical-bottom-after H-padding-vertical-both-10  H-touch-active H-position-relative" style="min-height: 80px;"><div class="H-text-align-center"><span class="H-icon H-center-all H-theme-background-color H-margin-horizontal-auto H-font-size-26 H-font-weight-600 H-border-radius-12 H-theme-font-color-white"><img src="../games/1486/picture/6.jpg" class="H-display-block" style="height:42px;width:42px;line-height:42px;"></span><label class="H-display-block H-font-size-11 H-margin-vertical-top-5 H-theme-font-color-666">谁能查看</label>
</div></a>

<a href="tixian.php" class="H-display-table-cell H-float-left H-box-sizing-border-box H-width-avg-4 H-center-all H-theme-background-color-white H-border-horizontal-right-after H-border-vertical-bottom-after H-padding-vertical-both-10  H-touch-active H-position-relative" style="min-height: 80px;"><div class="H-text-align-center"><span class="H-icon H-center-all H-theme-background-color H-margin-horizontal-auto H-font-size-26 H-font-weight-600 H-border-radius-12 H-theme-font-color-white"><img src="../games/1486/picture/8.jpg" class="H-display-block" style="height:42px;width:42px;line-height:42px;"></span><label class="H-display-block H-font-size-11 H-margin-vertical-top-5 H-theme-font-color-666">结算管理</label>
</div></a>
</div></div>

<div class="H-theme-background-color-white" style="margin-top:2px"><div class="H-border-vertical-bottom-after H-flexbox-horizontal">
<div class="H-flex-item H-text-show-row-1 H-padding-vertical-both-10 H-box-sizing-border-box H-border-horizontal-right-after H-touch-active"><a href="?id=1"><span class="H-font-size-14 H-theme-font-color-999 H-center-all">没开通会员</span></a></div>

<div class="H-flex-item H-text-show-row-1 H-padding-vertical-both-10 H-box-sizing-border-box H-border-horizontal-right-after H-touch-active"><a href="?id=2"><span class="H-font-size-14 H-theme-font-color-999 H-center-all">已开通会员</span></a></div>
</div></div>


<div style="height:2px"></div>
<form action="c.php" method="get" class="search_form">
<div class="H-padding-10 H-theme-background-color-white"><div class="H-search H-flexbox-horizontal H-box-sizing-border-box"><input type="search" name="text" placeholder="请输入关键字" class="H-border-none  H-theme-background-color-f4f4f4 H-flex-item H-font-size-16 H-padding-horizontal-both-10 H-padding-vertical-both-5" /><button class="H-button H-font-size-15 H-outline-none H-padding-vertical-both-5 H-padding-horizontal-both-20 H-theme-background-color1 H-theme-font-color-white H-theme-border-color1 H-theme-border-color1-click H-theme-background-color1-click H-theme-font-color1-click" style="min-width:0;">搜索</button></div></div>
</div></div>
</form>


<div id="list" class="H-padding-8">
<?php
$tj_vip_a=0;
$tj_vip_b=0;

if($_GET['id']=="1" or $_GET['id']==""){

$tj_vip_a=$my->t("select * from `user` where vip<>'yes'");
echo '
<p style="margin:8px">共有'.$tj_vip_a.'个没开通会员</p>';


$y=$tj_vip_a/20;

$re=mysqli_query($my->my_databaselink,"select * from `user` where vip<>'yes' order by id desc limit $x,20");

while($res=mysqli_fetch_assoc($re)){
echo '<div id="list1" class="H-border-radius3-px H-theme-background-color-white H-margin-vertical-bottom-5 H-border-vertical-both-after H-border-horizontal-both-after"><div class="H-padding-10 H-border-vertical-bottom-after H-flexbox-horizontal H-theme-font-color-999 H-font-size-14 H-flexbox-horizontal H-text-horizontal-left H-box-sizing-border-box"><span class="H-display-block H-flex-item H-text-align-left">'.date("Y-m-d H:i:s",$res['time']).'</span><span class="H-display-block H-flex-item H-text-align-right H-theme-font-color7-active">普通用户</span></div>
<div class="H-font-size-14 H-padding-10 H-flexbox-vertical"><div class="H-theme-font-color-333"><span class="H-float-left">账号:<a href="c.php?name='.$res['name'].'">'.$res['name'].'</a></span><span class="H-float-right">余额:'.$res['money'].'</span></div>

</div></div>';
}


}else{


$tj_vip_b=$my->t("select * from `user` where vip='yes'");
echo '
<p style="margin:8px">共有'.$tj_vip_b.'个已开通会员</p>';


$y=$tj_vip_b/20;

$re=mysqli_query($my->my_databaselink,"select * from `user` where vip='yes' order by id desc limit $x,20");

while($res=mysqli_fetch_assoc($re)){

echo '<div id="list1" class="H-border-radius3-px H-theme-background-color-white H-margin-vertical-bottom-5 H-border-vertical-both-after H-border-horizontal-both-after"><div class="H-padding-10 H-border-vertical-bottom-after H-flexbox-horizontal H-theme-font-color-999 H-font-size-14 H-flexbox-horizontal H-text-horizontal-left H-box-sizing-border-box"><span class="H-display-block H-flex-item H-text-align-left">'.date("Y-m-d H:i:s",$res['time']).'</span><span class="H-display-block H-flex-item H-text-align-right H-theme-font-color7-active">VIP会员</span></div>
<div class="H-font-size-14 H-padding-10 H-flexbox-vertical"><div class="H-theme-font-color-333"><span class="H-float-left">账号:<a href="c.php?name='.$res['name'].'">'.$res['name'].'</a></span><span class="H-float-right">余额:'.$res['money'].'</span></div></div></div>';
}

}


if($_GET['page']<=-1){
echo "<p style='margin:8px'>上一页什么也没有</p>";
//$_GET['page']=0;
}elseif($y<$_GET['page']){
//$_GET['page']=intval($y);
echo "<br/><p style='margin:8px'>已经是最后一页了</p>";
}

?>
</div></div>

  <div class="H-padding-vertical-bottom-10"></div>


<div class="H-theme-background-color-white "><div class="H-border-vertical-bottom-after H-flexbox-horizontal">

<div class="H-flex-item H-text-show-row-1 H-padding-vertical-both-10 H-box-sizing-border-box H-border-horizontal-right-after H-touch-active"><a href="<?php 
echo "?id={$_GET['id']}&page=";
echo $_GET['page']-1;
?>"><span class="H-font-size-14 H-theme-font-color-999 H-center-all">上一页</span></a></div>

<div class="H-flex-item H-text-show-row-1 H-padding-vertical-both-10 H-box-sizing-border-box H-border-horizontal-right-after H-touch-active"><span class="H-font-size-14 H-theme-font-color-999 H-center-all"><?php echo $_GET['page']+1; ?></span></div>

<div class="H-flex-item H-text-show-row-1 H-padding-vertical-both-10 H-box-sizing-border-box H-touch-active"><a href="<?php 
echo "?id={$_GET['id']}&page=";
echo $_GET['page']+1;
?>">
<span class="H-font-size-14 H-theme-font-color-999 H-center-all">下一页</span></a></div>

</div></div>
<div class="H-padding-vertical-bottom-10"><br/><br/></div>

</body>
</html>