<?php
require('../global.php');
require('system/config.php');
require('admin/decide.php');
require('system/my_connection.php');
require('system/my_operate.php');
if($logindecide==false){
header('location:index.php');
}


$c=$my->c("*","user","name='{$_GET['name']}'");


//print_r($c);

?>﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
<title>管理用户</title>
<link href="../style/hui.css" rel="stylesheet" type="text/css" />
</head>
<body class="H-theme-background-color-eee H-height-100-percent">

<header class="H-header H-theme-background-color1" id="header"><span tapmode="" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100" onclick="window.history.go(-1);"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i>返回</span>
<div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">
<?php echo $_GET['name']; ?>
</div></header>
<script language="javascript"> 
function s(str){ 
if(confirm(str)==true){
//alert("确认了");
location.href="s.php?name=<?php echo $c['name']; ?>";
}else{
alert("取消了");
}
} 
</script> 

<div class="H-padding-vertical-bottom-10" style="margin:8px"><button onclick="s('确认删除吗');" class="H-button H-width-100-percent  H-font-size-15 H-outline-none H-padding-vertical-both-12 H-padding-horizontal-both-20 H-theme-background-color2 H-theme-font-color-white H-theme-border-color2 H-theme-border-color2-click H-theme-background-color2-click H-theme-font-color2-click H-border-radius-3">删除这个用户</button></div>


  <div class="page">
    <div class="main">
      <form id="frm_login" method="post" action="cgai.php" style="margin:8px">
        <div class="item item-username">
<input type="hidden" name="id" value="<?php echo $c['id']; ?>">



<div class="H-padding-vertical-bottom-10"></div>
<div class="H-text-list H-flexbox-horizontal H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle H-touch-active"><div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">VIP</div>
<div class="H-padding-vertical-bottom-10"></div>
<input type="checkbox" class="H-switch H-switch-on-off-cn  H-position-relative H-theme-background-color-white H-theme-font-color5" name="vip" <?php if($c['vip']=="yes"){ echo 'checked="checked"'; } ?>/><span class="H-display-inline-block H-padding-horizontal-both-5"></span>
</div>


<div class="H-padding-vertical-bottom-10"></div>
<div class="H-text-list H-flexbox-horizontal H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle H-touch-active"><div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">锁定账号</div>
<div class="H-padding-vertical-bottom-10"></div>
<input type="checkbox" class="H-switch H-switch-on-off-cn  H-position-relative H-theme-background-color-white H-theme-font-color5" name="suo" <?php if($c['suo']=="yes"){ echo 'checked="checked"'; } ?>/><span class="H-display-inline-block H-padding-horizontal-both-5"></span>
</div>


<div class="H-padding-vertical-bottom-10"></div>
<div class="H-flexbox-horizontal H-border-vertical-bottom-margin-left-10-after">
<span class="H-icon H-vertical-middle H-padding-horizontal-left-10 H-theme-background-color-white"><i class="H-iconfont H-icon-lock H-font-size-18 H-vertical-middle"></i></span>
<input type="text" name="pass" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="密码"  value="<?php echo $c['pass']; ?>" /></div>


<div class="H-flexbox-horizontal H-border-vertical-bottom-margin-left-10-after">
<span class="H-icon H-vertical-middle H-padding-horizontal-left-10 H-theme-background-color-white"><i class="H-iconfont H-icon-fee H-font-size-18 H-vertical-middle"></i></span>
<input type="text" name="money" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="余额"  value="<?php echo $c['money']; ?>" /></div>

<div class="H-padding-vertical-bottom-10"></div>
<div class="H-padding-vertical-bottom-10"></div>
<button class="H-button H-width-100-percent  H-font-size-15 H-outline-none H-padding-vertical-both-12 H-padding-horizontal-both-20 H-theme-background-color1 H-theme-font-color-white H-theme-border-color1 H-theme-border-color1-click H-theme-background-color1-click H-theme-font-color9-click H-border-radius-3">确认修改</button>
</div>
</form>


<br/><br/><br/>

</body></html>