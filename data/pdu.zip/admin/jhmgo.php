<?php
require('../global.php');
require('system/config.php');
require('admin/decide.php');
require('system/my_connection.php');
require('system/my_operate.php');
if($logindecide==false){
header('location:index.php');
}

function jhm($pw_length = 10){
$randpwd = '';
for ($i = 0; $i < $pw_length; $i++){
$randpwd .= chr(mt_rand(48,57));
}
return $randpwd;
}


?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
<title>添加激活码</title>
<link href="../style/hui.css" rel="stylesheet" type="text/css" />
</head>
<body class="H-theme-background-color-eee H-height-100-percent">

<header class="H-header H-theme-background-color1" id="header"><span tapmode="" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100" onclick="window.history.go(-1);"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i>返回</span>
<div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">
添加激活码
</div></header>

<center style="margin-top:28px;font-size:18;">


<p class="msg" style="font-size:18px;color:red">

<?php
//print_r($_POST);

if($_GET['time']!='30'){
$_GET['time']='365';
}else{
$_GET['time']='30';
}


$res=mysqli_query($my->my_databaselink,"select * from `jhm` order by id desc");
$row=mysqli_fetch_assoc($res);

for($x=$row['id']; $x<=$row['id']+10; $x++){
$y=jhm(8);
$jhm=uniqid($y);


$myreg=$my->z("jhm","content,time,kg","'{$jhm}','{$_GET['time']}','no'");

echo $jhm;
echo "/添加成功<br/>";
}
?>
</p>

</head><body>