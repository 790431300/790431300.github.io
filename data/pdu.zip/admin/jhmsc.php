<?php
require('../global.php');
require('system/config.php');
require('admin/decide.php');
require('system/my_connection.php');
require('system/my_operate.php');

if($logindecide==false){
header('location:index.php');
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no"><title>栏目管理</title>
<link href="../style/hui.css" rel="stylesheet" type="text/css" />
<style type="text/css">
a{text-decoration:none;}
a:hover,a:active,a:link{}
a,li,ul{list-style-type:none}
.ac{background:#fff;color:#acacac;text-align:center;font-size:14px;padding:12px 0 12px 0;}
.ac p{line-height:18px}
.ac p a{text-decoration:none;color:#366}
#footer #foot{margin-top:7px;text-align:center;}
#footer #foot p .sp{padding:0 7px;}
#footer #foot p a{color:#444}</style>
</head><body>
<header class="H-header H-theme-background-color1" id="header">
<a href="javascript:history.back();"><span tapmode="" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i><label class="H-display-block H-vertical-middle H-font-size-15">返回</label></span></a>
<div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">删除提示</div></header>


<center style="margin-top:28px;font-size:18;">


<p class="msg" style="font-size:18px;color:red">

<?php
if($_GET['id']=="ok"){

$res=mysqli_query($my->my_databaselink,"truncate table jhm");
$row=mysqli_fetch_assoc($res);

echo "删除成功<br/>";
}else{
echo "确认删除吗?---<a href='?id=ok'>确认删除</a>";
}
?>
</p>

</head><body>