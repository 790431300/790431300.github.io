<?php
require('../global.php');
require('system/config.php');
require('admin/decide.php');
require('system/my_connection.php');
require('system/my_operate.php');
if($logindecide==false){
header('location:index.php');
}


$s=$my->s("user","name='{$_GET['name']}'");


?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" /><meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
<title>删除用户</title>
<link href="../style/hui.css" rel="stylesheet" type="text/css" />
</head>
<body class="H-theme-background-color-eee H-height-100-percent">

<header class="H-header H-theme-background-color1" id="header"><span tapmode="" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100" onclick="window.history.go(-1);"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i>返回</span>
<div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">
删除用户
</div></header>



<center style="padding:20px;color:red">
<?php
if($s){
echo "---------删除成功-------";
}else{
echo "---------删除失败--------";
}
?>
</center>


<br/><br/>


</body></html>