<?php
require('../global.php');
require('system/config.php');
require('admin/decide.php');
require('system/my_connection.php');
require('system/my_operate.php');
if($logindecide==false){
exit("error 404");
header('location:index.php');
}

if(!$_GET['page'] or $_GET['page']<0){
$_GET['page']=0;
}
?>﻿<!doctype html>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" />
    <meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
    <title>提现申请</title>
    <link href="../style/hui.css" rel="stylesheet" type="text/css" />
<style type="text/css">
.btn{position:relative;overflow:hidden;font-size:14px;vertical-align:middle;cursor:pointer;display:inline-block;*display:inline;width:100%;}
.btn input{position: absolute;top: 0; right: 0;margin: 0;border: solid transparent;opacity: 0;filter:alpha(opacity=0);cursor: pointer;width:100%;}
#upimg img{height:80px;}
button{border:0;}
</style>
</head>
<body class="H-theme-background-color-eee H-height-100-percent">

<header class="H-header H-theme-background-color1" id="header">
        <span tapmode="" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-z-index-100" onclick="window.history.go(-1);"><i class="H-iconfont H-icon-arrow-left H-font-size-18 H-vertical-middle"></i>返回</span>
        <div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">
提现申请</div></header>
    <p class="H-padding-horizontal-both-10 H-font-size-16">提现列表－<a href="?id=1">已结算</a>－<a href="?id=00">未结算</a></p>

    <div class="H-overflow-scrolling H-margin-10 H-position-relative">
        <table class="H-table H-table-fixed H-theme-background-color-white H-border-vertical-top-after H-border-horizontal-left-after">
            <thead>
                <tr>
                    <th class="H-padding-10 H-vertical-align-middle H-font-size-15 H-font-weight-500 H-theme-background-color-f4f4f4 H-border-vertical-bottom-after H-border-horizontal-right-after">收款方式</th>
                    <th class="H-padding-10 H-vertical-align-middle H-font-size-15 H-font-weight-500 H-theme-background-color-f4f4f4 H-border-vertical-bottom-after H-border-horizontal-right-after">姓名</th>

<th class="H-padding-10 H-vertical-align-middle H-font-size-15 H-font-weight-500 H-theme-background-color-f4f4f4 H-border-vertical-bottom-after H-border-horizontal-right-after">收款账号</th>
<th class="H-padding-10 H-vertical-align-middle H-font-size-15 H-font-weight-500 H-theme-background-color-f4f4f4 H-border-vertical-bottom-after H-border-horizontal-right-after">提现金额</th>

<th class="H-padding-10 H-vertical-align-middle H-font-size-15 H-font-weight-500 H-theme-background-color-f4f4f4 H-border-vertical-bottom-after H-border-horizontal-right-after">申请状态</th></tr>
            </thead>

<tbody>

<?php

if(!@$_GET['page']){
@$_GET['page']=0;
}
$x=@$_GET['page']*60;

$y=$t/60;
if($_GET['id']=="0"){
$sql="select * from `tixian` where zhuangtai='0' order by id desc limit {$x},60";
}else{
$sql="select * from `tixian` where zhuangtai='1' order by id desc limit {$x},60";
}
$re=mysqli_query($my->my_databaselink,"$sql");

while($res=mysqli_fetch_assoc($re)){

echo "<tr><td class=\"H-padding-10 H-vertical-align-middle H-font-size-14 H-border-vertical-bottom-after H-border-horizontal-right-after\"><span class=\"H-display-inline-block H-padding-horizontal-both-5 H-theme-font-color1\">{$res['payname']}</span></td>

<td class=\"H-padding-10 H-vertical-align-middle H-font-size-14 H-border-vertical-bottom-after H-border-horizontal-right-after\">{$res['payuser']}</td>

<td class=\"H-padding-10 H-vertical-align-middle H-font-size-14 H-border-vertical-bottom-after H-border-horizontal-right-after\">{$res['payphone']}</td>
<td class=\"H-padding-10 H-vertical-align-middle H-font-size-14 H-border-vertical-bottom-after H-border-horizontal-right-after\">{$res['money']}</td>
                
<td class=\"H-padding-10 H-vertical-align-middle H-font-size-14 H-border-vertical-bottom-after H-border-horizontal-right-after\"><span class=\"H-display-inline-block H-padding-horizontal-both-5 H-theme-font-color1\" >";

if($res['zhuangtai']=="1"){
echo '申请已到账';
}else{
echo '申请中…<a href="tixian-go.php?id='.$res['id'].'">结算</a>';
}

echo "</span></tr>";
}
?>
    
</tbody></table></div>
<br/><br/><br/>





<?php


if($_GET['page']<=-1){
echo "<p style='margin:8px'>上一页什么也没有</p>";
$_GET['page']=0;
}elseif($y<$_GET['page']){
$_GET['page']=intval($y);
echo "<br/><p style='margin:8px'>已经是最后一页了</p>";
}

?>
</div></div>

  <div class="H-padding-vertical-bottom-10"></div>


<div class="H-theme-background-color-white "><div class="H-border-vertical-bottom-after H-flexbox-horizontal">

<div class="H-flex-item H-text-show-row-1 H-padding-vertical-both-10 H-box-sizing-border-box H-border-horizontal-right-after H-touch-active"><a href="<?php 
echo "?id={$_GET['id']}&page=";
echo $_GET['page']-1;
?>"><span class="H-font-size-14 H-theme-font-color-999 H-center-all">上一页</span></a></div>

<div class="H-flex-item H-text-show-row-1 H-padding-vertical-both-10 H-box-sizing-border-box H-border-horizontal-right-after H-touch-active"><span class="H-font-size-14 H-theme-font-color-999 H-center-all"><?php echo $_GET['page']+1; ?></span></div>

<div class="H-flex-item H-text-show-row-1 H-padding-vertical-both-10 H-box-sizing-border-box H-touch-active"><a href="<?php 
echo "?id={$_GET['id']}&page=";
echo $_GET['page']+1;
?>">
<span class="H-font-size-14 H-theme-font-color-999 H-center-all">下一页</span></a></div>


</div></div>
<div class="H-padding-vertical-bottom-20"></div>
</body>
</html>