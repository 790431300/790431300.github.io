<?php
sleep(5);
header("location:index.php");